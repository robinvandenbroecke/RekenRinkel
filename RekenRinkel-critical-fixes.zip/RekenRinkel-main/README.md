# RekenRinkel

Educatieve rekenapp voor jonge kinderen. Deze repository is een **privétestbasis** voor een lokale Android-app. De app is nog niet productierijp en nog niet bedoeld voor Play Store-publicatie.

## Status per onderdeel

| Onderdeel | Status | Nuchtere beoordeling |
|---|---|---|
| Android-project | Basis aanwezig | Kotlin/Compose-project met Gradle-wrapper. Build moet in een omgeving met internet/Android SDK gevalideerd worden. |
| ExerciseEngine | Functioneel aanwezig | Genereert kernopgaven. Enkele regressies rond visuele vragen en splitsingen zijn aangescherpt. Verdere gebruiksvalidatie blijft nodig. |
| Didactic rules | Verbeterd | String-map regels zijn vervangen door typed rules met enums/data classes voor o.a. bridge, step, visual prompt, compare mode en multiplication mode. |
| ExerciseValidator | Verbeterd | Validatie is consistenter. Splitsingen accepteren niet langer enkel het totaal als correct antwoord. |
| SessionEngine | Functioneel aanwezig | Adaptieve selectie bestaat. De heuristiek is bruikbaar voor privétest, maar nog geen bewezen didactisch eindmodel. |
| Response-time tracking | Aanwezig | Timing zit in de flow. End-to-end gedrag moet verder op echte toestellen gecontroleerd worden. |
| UI-schermen | Basis aanwezig | Functioneel genoeg voor interne test. Nog niet gepolijst als commercieel kinderproduct. |
| Parent dashboard | Basis aanwezig | Bruikbaar als eerste overzicht, nog niet als volwaardig rapportagesysteem. |
| Premium-flow | Placeholder | Niet gebruiken als echte monetisatie. |
| Tests | Aanwezig en uitgebreid | Dekt generator/validator/content deels. Geen vervanging voor device-tests. |

## Belangrijkste wijzigingen in deze iteratie

- Extra typed regels toegevoegd:
  - `ComparePromptMode`
  - `MultiplicationMode`
  - `DidacticRule.ComparePrompt`
  - `DidacticRule.MultiplicationPresentation`
- `advanced_compare_100`, `advanced_groups` en tafelconfiguraties gebruiken nu expliciete typed presentatie-regels.
- Bugfix in duplicate-regeneratie: `foundation_number_bonds_5` blijft nu tot 5 genereren en valt niet terug naar 10.
- Duplicate-memory gebruikt nu de vraagtekst zelf in plaats van hash-strings.
- Validator aangescherpt: bij split-antwoorden zoals `2 en 3` wordt `5` niet langer als correct geaccepteerd.
- Antwoordopties in Compose worden per oefening vastgezet met `remember(exercise.id)` zodat ze niet herschikken bij recomposition.
- Regressietests toegevoegd voor typed rules en split-validatie.

## Build & test

In een lokale Android-ontwikkelomgeving:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

De debug-APK staat na een geslaagde build normaal onder:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Data & privacy

- Lokale opslag via Room/DataStore.
- Geen account.
- Geen cloud.
- Geen advertenties.
- Geen tracking-SDK.

## Niet-goals voor deze fase

- Geen Play Store-release.
- Geen echte billing.
- Geen multi-user cloudsync.
- Geen claims over bewezen leerwinst.

## Licentie

Privé testbuild. Copyright behouden door de repository-eigenaar.
