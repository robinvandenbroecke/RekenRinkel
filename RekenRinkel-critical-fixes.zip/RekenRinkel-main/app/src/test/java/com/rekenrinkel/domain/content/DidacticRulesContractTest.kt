package com.rekenrinkel.domain.content

import org.junit.Assert.*
import org.junit.Test

class DidacticRulesContractTest {

    @Test
    fun `typed rules expose bridge zero visual compare and multiplication constraints`() {
        val rules = DidacticRules.build {
            range(1, 20)
            requireBridgeThroughTen()
            requireVisualPrompt()
            comparePromptMode(ComparePromptMode.EXPLICIT_SYMBOL)
            multiplicationMode(MultiplicationMode.GROUPS_FIRST)
            exactStep(5)
            maxResult(20)
            requireEven()
        }

        assertEquals(1, rules.valueRange?.min)
        assertEquals(20, rules.valueRange?.max)
        assertTrue(rules.requireBridge)
        assertEquals(5, rules.step)
        assertEquals(20, rules.maxResult)
        assertTrue(rules.requireEven)
        assertEquals(ComparePromptMode.EXPLICIT_SYMBOL, rules.comparePromptMode)
        assertEquals(MultiplicationMode.GROUPS_FIRST, rules.multiplicationMode)
        assertNotNull(rules.find<DidacticRule.RequiresVisualPrompt>())
    }

    @Test
    fun `core configs no longer depend on string based rules`() {
        val compare = ContentRepository.getConfig("advanced_compare_100")!!
        assertEquals(ComparePromptMode.EXPLICIT_SYMBOL, compare.rules.comparePromptMode)
        assertNotNull(compare.rules.find<DidacticRule.MinDifference>())

        val groups = ContentRepository.getConfig("advanced_groups")!!
        assertEquals(MultiplicationMode.GROUPS_FIRST, groups.rules.multiplicationMode)

        val table2 = ContentRepository.getConfig("advanced_table_2")!!
        assertEquals(2, table2.rules.multiplier)
        assertEquals(MultiplicationMode.TABLE_FACT, table2.rules.multiplicationMode)
    }
}
