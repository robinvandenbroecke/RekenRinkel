package com.rekenrinkel.domain.engine

import com.rekenrinkel.domain.model.Exercise
import com.rekenrinkel.domain.model.ExerciseType
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ExerciseValidatorRegressionTest {
    private lateinit var validator: ExerciseValidator

    @Before
    fun setup() {
        validator = ExerciseValidator()
    }

    @Test
    fun `split visual group requires split parts not only total`() {
        val exercise = Exercise(
            skillId = "foundation_splits_10",
            type = ExerciseType.VISUAL_GROUPS,
            difficulty = 2,
            question = "5 = ? + ?",
            correctAnswer = "2 en 3",
            distractors = listOf("1 en 4", "5 en 0", "2 en 2")
        )

        assertTrue(validator.validate(exercise, "2 en 3"))
        assertTrue(validator.validate(exercise, "3 en 2"))
        assertFalse("Alleen het totaal is geen correct split-antwoord", validator.validate(exercise, "5"))
    }

    @Test
    fun `numeric visual group still accepts numeric total`() {
        val exercise = Exercise(
            skillId = "advanced_groups",
            type = ExerciseType.VISUAL_GROUPS,
            difficulty = 3,
            question = "3 groepjes van 4 is hoeveel samen?",
            correctAnswer = "12",
            distractors = listOf("11", "13", "8")
        )

        assertTrue(validator.validate(exercise, "12"))
        assertFalse(validator.validate(exercise, "3 en 4"))
    }
}
